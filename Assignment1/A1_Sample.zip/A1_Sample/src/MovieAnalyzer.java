
public class MovieAnalyzer {

}